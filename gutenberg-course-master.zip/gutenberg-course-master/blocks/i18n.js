wp.i18n.setLocaleData( { '': {} }, 'jsforwpblocks' );
