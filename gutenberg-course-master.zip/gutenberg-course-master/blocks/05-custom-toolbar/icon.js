const icon = <svg width='20px' height='20px' viewBox='0 0 100 100' xmlns='http://www.w3.org/2000/svg'>
    <path d='m5 95h90v-90h-90zm10-70h10v-10h10v10h10v10h-10v10h-10v-10h-10zm70-10v70h-70z'
    />
    <path d='m45 65h30v10h-30z' />
</svg>;

export default icon;
